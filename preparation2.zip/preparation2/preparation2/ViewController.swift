//
//  ViewController.swift
//  preparation2
//
//  Created by Jyothsna Naredla on 11/13/23.
//

import UIKit

class ViewController: UIViewController {
    
    var i=""
    
    var H = 0.0
    
    @IBOutlet weak var WeightOL: UITextField!
    
    
    @IBOutlet weak var HeightOL: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }
    

    @IBAction func CalculateBMI(_ sender: UIButton) {
        
        var Weight = Double(WeightOL .text!) ?? 0.0
        var Height = Double(HeightOL.text!) ??  0.0
        H = ((Weight)/(Weight*Height))*703
        
        if (H <= 18.4)
        {
            i = "UnderWeight"
            
            
        }
        else if (H >= 18.4 && H <= 25.0 ) {
            i = "Normal"
            
        }
        else if (H >= 25.0 && H <= 39.9) {
            i = "overweight"
        }
        else  {
            i = "obese"
        }
    }
        
        

    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if (transition == "Resultsegue") {
            var destination = segue.destination as! ResultViewController
            destination.j = WeightOL.text!
            destination.k = HeightOL.text!
            destination.l = H
            destination.imag = i
        }
    }
    
}

