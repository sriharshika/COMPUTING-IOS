//
//  ResultViewController.swift
//  preparation2
//
//  Created by Jyothsna Naredla on 11/13/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var Enterdweight: UILabel!
    
    
    
    @IBOutlet weak var Enterdheight: UILabel!
    
    
    @IBOutlet weak var EntredBMI: UILabel!
    
    
    @IBOutlet weak var ImageView: UIImageView!
    
    
    
    var j = ""
    var k = ""
    var l = 0.0
    var imag = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Enterdweight.text! += j
        Enterdheight.text! += k
        EntredBMI.text! += String(l)
        ImageView.image = UIImage(named: imag)
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
