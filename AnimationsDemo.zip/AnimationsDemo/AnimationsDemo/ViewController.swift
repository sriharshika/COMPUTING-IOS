//
//  ViewController.swift
//  AnimationsDemo
//
//  Created by sri harshika sattor on 10/24/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet weak var imageviewOL: UIImageView!
    
    
    @IBOutlet weak var happyOL: UIButton!
    
    
    @IBOutlet weak var sadOL: UIButton!
    
    
    
    @IBOutlet weak var angryOL: UIButton!
    
    
    
    @IBOutlet weak var shakemeOL: UIButton!
    
    
    
    
    @IBOutlet weak var showmeOL: UIButton!
    
    
    override func viewDidAppear(_ animated: Bool) {
        
        //move the imageview outside of thescreen view
        imageviewOL.frame.origin.x = view.frame.maxX
        happyOL.frame.origin.x = view.frame.width
        sadOL.frame.origin.x = view.frame.width
        angryOL.frame.origin.x = view.frame.width
        shakemeOL.frame.origin.x = view.frame.width
        
        //similarly move other conponents outside of the screen
        
    }
    
    @IBAction func happybtnclicked(_ sender: UIButton) {
        updateandAnimate("happy")
    }
    
    
    @IBAction func sadbtnclicked(_ sender: UIButton) {
        updateandAnimate("sad")
        
    }
    
    
    
    @IBAction func angrybtnclicked(_ sender: UIButton) {
        updateandAnimate("angry")
    }
    
    
    
    @IBAction func shakemebtnclicked(_ sender: UIButton) {
        var width = imageviewOL.frame.width
        width += 40
        
        var height = imageviewOL.frame.height
        height += 40
        
        var x = imageviewOL.frame.origin.x - 20
        var y = imageviewOL.frame.origin.y - 20
        
        //create a rectangle object
        
        var largeframe = CGRect(x: x, y: y, width: width, height: height)
        
        UIView.animate(withDuration: 1, delay: 0, 
                       usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
            self.imageviewOL.frame = largeframe
        })
        
        
        
        
    }
    
    
    
    
    @IBAction func showmebtn(_ sender: UIButton) {
        UIView.animate(withDuration: 1, animations: {
            
            //moving all components to centre
            
            self.happyOL.center.x = self.view.center.x
            
            self.sadOL.center.x = self.view.center.x
            
            self.angryOL.center.x = self.view.center.x
            
            self.shakemeOL.center.x = self.view.center.x

            
        })
        
        //disable the showme button
        showmeOL.isEnabled = false
        
        
    }
    
    func updateandAnimate(_ imageName: String){
        //make the current image as opaque.(alpha should be zero)
        UIView.animate(withDuration: 1, animations:{
            self.imageviewOL.alpha = 0
        } )
        
        
        //and assign the new image with animation and make it transparent (alpha should be 1)
        UIView.animate(withDuration: 1, delay : 0.5, animations: {
            self.imageviewOL.alpha = 1
            self.imageviewOL.image = UIImage(named : imageName)
        })
        
    }
    
}

