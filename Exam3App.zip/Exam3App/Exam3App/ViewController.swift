//
//  ViewController.swift
//  Exam3App
//
//  Created by sri harshika sattor on 11/30/23.
//

import UIKit

class Words{
    var wordName : String?
    var wordNumber : String?
    
    
    init(wordName: String?, wordNumber: String?){
        self.wordName = wordName
        self.wordNumber = wordNumber
    }
    
}



class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return words.count
    
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        var cell = VCTableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath)
        
        cell.textLabel?.text = words[indexPath.row][0]
        
        return cell
    }
    

    @IBOutlet weak var VCTableView: UITableView!
    
    
    
    var words = [["sonu1", "12345678"],["sonu2", "12345678"],["sonu3", "12345678"],["sonu4", "12345678"],["sonu5", "12345678"],["sonu6", "12345678"],["sonu7", "12345678"],["sonu8", "12345678"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        VCTableView.delegate = self
        VCTableView.dataSource = self
        
        self.title = "Details_abc"
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            
            let transition = segue.identifier
            if(transition=="resultSegue") {
                let destination = segue.destination as! detailsViewController
                destination.word = words[(VCTableView.indexPathForSelectedRow?.row)!]
                

            }
        }
    
}

