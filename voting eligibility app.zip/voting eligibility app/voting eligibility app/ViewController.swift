//
//  ViewController.swift
//  voting eligibility app
//
//  Created by sri harshika sattor on 9/5/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func checkeligbtn(_ sender: Any) {
        //reading the input
        var input = inputOL.text
        var output =  outputOL.text
        var num = Double(inputOL.text!) ?? 0
        if(num >= 18){
            outputOL.text = "The person is eligible for voting"
            }
        else{
            outputOL.text = "The person is not eligible for voting"
        }
    }
    
}

