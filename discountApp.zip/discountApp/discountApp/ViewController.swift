//
//  ViewController.swift
//  discountApp
//
//  Created by sri harshika sattor on 9/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var amountOL: UITextField!
    
    
    @IBOutlet weak var discountOL: UITextField!
    
    

    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func discountbtn(_ sender: Any) {
        var inputamountOL = Double(amountOL.text!) ?? 0
        var discountOL = Double(discountOL.text!) ?? 0
        var DiscountOL =
        (discountOL / inputamountOL) * 100
        var result = inputamountOL - discountOL
        outputOL.text! = "discount price is \(result)"
    }
    
    

}

