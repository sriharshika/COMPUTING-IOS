//
//  ViewController.swift
//  Sattor_CalculatorApp
//
//  Created by sri harshika sattor on 9/24/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var resultOutlet: UILabel!
    
    var presentnumber : Double = 0
    var previousnumber : Double = 0
    var operation = ""
    var output : Int = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        resultOutlet.textColor = .white
        view.backgroundColor = .black
        
    }

    
    @IBAction func allclearBTN(_ sender: UIButton) {
        clear()
    }
    
    func clear(){
        resultOutlet.text = ""
    }
    
    @IBAction func clearBTN(_ sender: UIButton) {
        output = 0
        clear()
    }
    
    
    @IBAction func changesignBTN(_ sender: UIButton) {
        if let currentnumber = Double(resultOutlet.text!){
            let newnumber = -currentnumber
            resultOutlet.text = String(newnumber)
        }
    }
    
    
    @IBAction func divisionBTN(_ sender: UIButton) {
        operation = "÷"
        presentnumber = Double(resultOutlet.text!)!
        clear()
    }
    
    
    
    @IBAction func multiplicationBTN(_ sender: UIButton) {
        operation = "*"
        presentnumber = Double(resultOutlet.text!)!
        clear()
    }
    
    
    @IBAction func substractionBTN(_ sender: UIButton) {
        operation = "-"
        presentnumber = Double(resultOutlet.text!)!
        clear()
    }
    
    
    @IBAction func additionBTN(_ sender: UIButton) {
        operation = "+"
        presentnumber = Double(resultOutlet.text!)!
        clear()
    }
    
    
    
    
    
    @IBAction func equalsBTN(_ sender: UIButton) {
        previousnumber = Double(resultOutlet.text!)!
        
        switch operation{
        case "+" :
            output = Int(presentnumber + previousnumber)
            resultOutlet.text = String(Int(exactly : output)!)
        case "-" :
            output = Int(presentnumber - previousnumber)
            resultOutlet.text = String(Int(exactly : output)!)
        case "%" :
            let remainder = presentnumber.truncatingRemainder(dividingBy: previousnumber)
            resultOutlet.text = String(format : "%.1f", remainder)
        case "*" :
            output = Int(presentnumber*previousnumber)
            resultOutlet.text = String(output)
        case "÷":
            if previousnumber == 0 {
                resultOutlet.text = "Is NOT a number"
                }
            else {
                let unRoundResult = presentnumber/previousnumber
                resultOutlet.text = String(format : "%.5f", unRoundResult)
            }
        default :
            resultOutlet.text = "ERROR"
            
            
            
        }
    }
    
    
    
    @IBAction func percentageBTN(_ sender: UIButton) {
        operation = "%"
        presentnumber = Double(resultOutlet.text!)!
        clear()
    }
    
    
    
    @IBAction func nineBTN(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text! + "9"
    }
    
    
    @IBAction func eightBTN(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text! + "8"
    }
    
    
    
    @IBAction func sevenBTN(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text! + "7"
    }
    
    
    @IBAction func sixBTN(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text! + "6"
    }
    
    
    
    @IBAction func fiveBTN(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text! + "5"
    }
    
    
    @IBAction func fourBTN(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text! + "4"
    }
    
    
    @IBAction func threeBTN(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text! + "3"
    }
    
    
    @IBAction func twoBTN(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text! + "2"
    }
    
    
    @IBAction func oneBTN(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text! + "1"
    }
    
    
    @IBAction func zeroBTN(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text! + "0"
    }
    
    
    @IBAction func decimalpointBTN(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text! + "."
    }
    
}

