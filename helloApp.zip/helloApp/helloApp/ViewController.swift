//
//  ViewController.swift
//  helloApp
//
//  Created by sri harshika sattor on 10/4/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameinput: UITextField!
    
    
    @IBOutlet weak var ageinput: UITextField!
    
    
    
    @IBOutlet weak var displayresult: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitbtn(_ sender: UIButton) {
        //READ THE INPUT FROM NAME AND AGE
        var name = nameinput.text!
        var age = ageinput.text!
        
        //DISPLAY THE AGE AND AGE IN THE RESULT LABEL
        displayresult.text = ("hello,\(name) and your age is \(age)")
        print(displayresult.text!)
        
        
    }
    
}

